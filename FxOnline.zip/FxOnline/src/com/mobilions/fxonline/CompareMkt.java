package com.mobilions.fxonline;
import java.util.Comparator;

import com.mobilions.fxservices.reportdata.CurrencyData;

public class CompareMkt implements Comparator<CurrencyData>{

	public int compare(CurrencyData o1, CurrencyData o2) {
		if(o1.getMarkateMidPrice()>o2.getMarkateMidPrice())
			return 1;
		else if(o1.getMarkateMidPrice()<o2.getMarkateMidPrice())
			return -1;
		else
			return 0;
	}
	
}
