package com.mobilions.fxonline;


import com.mobilions.fxservices.utils.DatabaseManager;
import com.mobilions.fxservices.utils.Settings;

import android.graphics.Color;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

public class NorSettingsFragment extends Fragment{

	String[] curs;
	String[] mkts;
	String[] ints;
	DatabaseManager dbMan;
	private boolean nextTime = false;
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		View rootView = inflater.inflate(R.layout.settingsfragment, container, false);
		final TextView switchStatus=(TextView) rootView.findViewById(R.id.curtext);

		curs = getResources().getStringArray(R.array.ccyArray);
		ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(getActivity().getApplicationContext(),
				android.R.layout.simple_spinner_item,curs);
		dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		
		dbMan = new DatabaseManager(getContext());
		if(!dbMan.ifExist()){
			dbMan.createTable();
			dbMan.insertSettings(Settings.quoteCurrency, Settings.mktVenue, Settings.refreshInterval, Settings.notification?1:0);
		}

		Spinner spinner1 = (Spinner) rootView.findViewById(R.id.curspinner);
		spinner1.setAdapter(dataAdapter);

		spinner1.setOnItemSelectedListener(new OnItemSelectedListener(){
			
			@Override
			public void onItemSelected(AdapterView<?> parent, View view,
		            int pos, long id) {
		       String item = parent.getItemAtPosition(pos).toString();
//		       ((TextView) parent.getChildAt(0)).setTextColor(Color.BLACK);
//				
//			      Toast.makeText(parent.getContext(), "Selected: " + item, Toast.LENGTH_LONG).show();
		       Settings.quoteCurrency = item;
		       if(dbMan != null && dbMan.ifExist()){
		    	   dbMan.updateQuoteCCY(item);
		       }
		       if(nextTime)
		    	   Toast.makeText(parent.getContext(), "Quote CCY configured as " + item+" for the next run.", Toast.LENGTH_LONG).show();
		       else
		    	   nextTime = true;
			      
		    }

		    public void onNothingSelected(AdapterView<?> parent) {
		        
		    }
		});

		mkts = getResources().getStringArray(R.array.marketarray);
		ArrayAdapter<String> dataAdapter1 = new ArrayAdapter<String>(getActivity().getApplicationContext(),
				android.R.layout.simple_spinner_item,mkts);
		dataAdapter1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

		Spinner spinner2 = (Spinner) rootView.findViewById(R.id.marketspinner);
		spinner2.setAdapter(dataAdapter1);
		spinner2.setOnItemSelectedListener(new OnItemSelectedListener(){
			
			@Override
			public void onItemSelected(AdapterView<?> parent, View view,
		            int pos, long id) {
		       String item = parent.getItemAtPosition(pos).toString();
//		       ((TextView) parent.getChildAt(0)).setTextColor(Color.BLACK);
//				
//			      Toast.makeText(parent.getContext(), "Selected: " + item, Toast.LENGTH_LONG).show();
			    Settings.mktVenue = item;  
			    if(dbMan != null && dbMan.ifExist()){
			    	   dbMan.updateMktVenue(item);
			    }
		          
		    }

		    public void onNothingSelected(AdapterView<?> parent) {
		        
		    }
		});

		ints = getResources().getStringArray(R.array.intarray);
		ArrayAdapter<String> dataAdapter2 = new ArrayAdapter<String>(getActivity().getApplicationContext(),
				android.R.layout.simple_spinner_item,ints);
		dataAdapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

		Spinner spinner3 = (Spinner) rootView.findViewById(R.id.timeintspinner);
		spinner3.setAdapter(dataAdapter2);
		spinner3.setOnItemSelectedListener(new OnItemSelectedListener(){
			
			@Override
			public void onItemSelected(AdapterView<?> parent, View view,
		            int pos, long id) {
		       String item = parent.getItemAtPosition(pos).toString();
//		       ((TextView) parent.getChildAt(0)).setTextColor(Color.BLACK);
				  
		        Settings.refreshInterval = Integer.parseInt(item);  
		        if(dbMan != null && dbMan.ifExist()){
			    	   dbMan.updateInterval(Integer.parseInt(item));
			    }
		    }

		    public void onNothingSelected(AdapterView<?> parent) {
		        
		    }
		});

		Switch mySwitch = (Switch) rootView.findViewById(R.id.mySwitch);

		mySwitch.setChecked(true);

		OnCheckedChangeListener listener=new OnCheckedChangeListener() {

			@Override
			public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
				Settings.notification = isChecked;
				// TODO Auto-generated method stub
				if(dbMan != null && dbMan.ifExist()){
			    	   
					if(isChecked){
						//switchStatus.setText("Switch is currently ON");
						dbMan.updateNotification(1);
					}else{
						//  switchStatus.setText("Switch is currently OFF");
						dbMan.updateNotification(0);
					}
				}
			}

		};

		mySwitch.setOnCheckedChangeListener(listener);
		//attach a listener to check for changes in state
		/*mySwitch.setOnCheckedChangeListener(new OnCheckedChangeListener() {

			   @Override
			   public void onCheckedChanged(CompoundButton buttonView,
			     boolean isChecked) {

			    if(isChecked){
			     switchStatus.setText("Switch is currently ON");
			    }else{
			     switchStatus.setText("Switch is currently OFF");
			    }

			   }
			  });

		 */
		return rootView;
	}

}
