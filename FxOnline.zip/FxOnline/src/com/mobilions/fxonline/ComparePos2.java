package com.mobilions.fxonline;
import java.util.Comparator;

import com.mobilions.fxservices.reportdata.CurrencyData;

public class ComparePos2 implements Comparator<CurrencyData>{

	public int compare(CurrencyData o1, CurrencyData o2) {
		if(o1.getBasePositon()>o2.getBasePositon())
			return 1;
		else if(o1.getBasePositon()<o2.getBasePositon())
			return -1;
		else
			return 0;
	}
	
}
