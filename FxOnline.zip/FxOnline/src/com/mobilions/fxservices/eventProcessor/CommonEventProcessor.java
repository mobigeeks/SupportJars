package com.mobilions.fxservices.eventProcessor;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Logger;

import com.mobilions.fxservices.event.DealEvent;
import com.mobilions.fxservices.event.FxEvent;
import com.mobilions.fxservices.event.QuoteEvent;
import com.mobilions.fxservices.utils.SharedPrefs;

public class CommonEventProcessor{
	
	private static final Logger logger = Logger.getLogger(CommonEventProcessor.class.getName());
	private DealEventProcessor dealProcessor;
	private QuoteEventProcessor quoteProcessor;
	private long timeDiff = 0;
	private final SimpleDateFormat df = new SimpleDateFormat("HH:mm:ss.SSS");
	private long lastTimeStamp = 0;
	
	public CommonEventProcessor(){
		dealProcessor = new DealEventProcessor();
		quoteProcessor = new QuoteEventProcessor();
	}

	public void processEvent(String[] event) {
		// TODO Auto-generated method stub
		if(event != null){
			int noOfParams = event.length;
			if(noOfParams == 6){
				long timeStamp = 0;
				try {
					Date date = df.parse(event[1]);
					timeStamp = date.getTime();
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				if(timeDiff == 0){
					timeDiff = System.currentTimeMillis() - timeStamp;
				}
				long timeStampDiff = timeStamp - lastTimeStamp;
				long curTimeDiff = System.currentTimeMillis() - (lastTimeStamp + timeDiff);
				while (lastTimeStamp != 0 && curTimeDiff < timeStampDiff){
					try {
						Thread.sleep(timeStampDiff-curTimeDiff);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					curTimeDiff = System.currentTimeMillis() - (lastTimeStamp + timeDiff);
				}
				lastTimeStamp = timeStamp;
				FxEvent newEvent;
				if("quote".equalsIgnoreCase(event[0])){
					newEvent = new QuoteEvent((timeStamp+timeDiff), event[2], event[3], 
							Float.parseFloat(event[4]), Float.parseFloat(event[5]));
					quoteProcessor.processEvent(newEvent);
				}else{
					newEvent = new DealEvent((timeStamp+timeDiff), event[2], Double.parseDouble(event[3]), 
							Float.parseFloat(event[4]), event[5]);
					dealProcessor.processEvent(newEvent);
				}
			}else{
				logger.warning("Invalid event received: " + event[0]);
			}
		}
	}

}
