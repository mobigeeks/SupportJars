package com.mobilions.fxservices.utils;

import java.lang.reflect.Type;
import java.util.Map;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.mobilions.fxservices.reportdata.CurrencyData;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.util.Log;

public class SharedPrefs {
	private static final String PREFS_NAME = "FxWatchPrefsFile";
	private static final String MAP_NAME = "DataMap";
	
	public static void save(Context ctx, Map<String, CurrencyData> updatedMap){
		SharedPreferences sharedPrefs = ctx.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
		Editor prefsEditor = sharedPrefs.edit();
		Gson gson = new Gson();
        String json = gson.toJson(updatedMap);
        prefsEditor.putString(MAP_NAME, json);
        prefsEditor.commit();
        Log.i(PREFS_NAME, "DataMap saved...");
	}	
	
	public static Map<String, CurrencyData> load(Context ctx){
		SharedPreferences sharedPrefs = ctx.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
		Gson gson = new Gson();		
        String json = sharedPrefs.getString(MAP_NAME, "");
        Type type = new TypeToken<Map<String, CurrencyData>>(){}.getType();
        Map<String, CurrencyData> datamap = gson.fromJson(json, type);        
        Log.i(PREFS_NAME, "DataMap loaded...");
        return datamap ;
	}
}
