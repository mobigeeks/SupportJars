package com.mobilions.fxservices.utils;

public class Settings {
	public static String quoteCurrency = "USD";
	public static String mktVenue = "AGG";
	public static int refreshInterval = 2;
	public static boolean notification = true;
	
}
