package com.mobilions.fxservices.utils;

public interface AppConstants {
	
	String DATABASE_NAME = "fxMon";
	
	String SETTING_TABLE_NAME = "setting";
	String CREATE_SETTING_TABLE = "create table IF NOT EXISTS setting " +
									"(quoteCCY string, mktVenue string,interval integer, notification integer)";
	String SELECT_SETTING_TABLE = "select * from setting";
	
	String DROP_TABLE = "drop table IF EXISTS ";
	
	String COLUMN_CCY = "quoteCCY";
	String COLUMN_MKT = "mktVenue";
	String COLUMN_INTERVAL = "interval";
	String COLUMN_NOTIFICATION = "notification";
	String CHECK_TABLE = "select name from sqlite_master where type='table' and "
			+ "name = ?";
	
}
