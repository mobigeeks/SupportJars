/**
 * Implementation of EventReceiver interface which reads Fx events from a file
 */
package com.mobilions.fxservices.eventReceiver;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.logging.Logger;

import com.mobilions.fxservices.eventProcessor.CommonEventProcessor;
import com.mobilions.fxservices.utils.FieldSeparatedFileReader;

/**
 * @author trivedi1
 *
 */
public class FileEventReceiver implements EventReceiver {
	
	private static final Logger logger = Logger.getLogger(FileEventReceiver.class.getName());
	
	private String fileName;
	private String separator;
	private CommonEventProcessor eventProcessor;
	
	public FileEventReceiver(String fileName, String separator){
		this.fileName = fileName;
		this.separator = separator;
		eventProcessor = new CommonEventProcessor();
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FileEventReceiver receiver = new FileEventReceiver("assets\\input.csv", ",");
		receiver.receiveFxEvent();
	}

	@Override
	public void receiveFxEvent() {
		// TODO Auto-generated method stub
		if(fileName != null && separator != null){
			try {
				FieldSeparatedFileReader fileReader = new FieldSeparatedFileReader(fileName, separator);
				String[] nextEvent;
	
				while((nextEvent = fileReader.getNextLine()) != null){
					eventProcessor.processEvent(nextEvent);
				}
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}else{
			logger.warning("File Name or separator is not specified.");
		}
	}

}
